package com.sb.githubsbintegration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GithubSbIntegrationApplicationTests {

    @Test
    void contextLoads() {
    }

}
