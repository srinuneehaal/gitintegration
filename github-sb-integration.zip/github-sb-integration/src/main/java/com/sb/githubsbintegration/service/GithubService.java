package com.sb.githubsbintegration.service;

import com.sb.githubsbintegration.model.GithubRepoResopnse;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;

@Service
public class GithubService {

    private final WebClient webClient;

    public GithubService(WebClient.Builder webClientBuilder) {

        this.webClient = webClientBuilder
                .baseUrl("https://api.github.com")
                .build();
        }

        public Mono<List<String>> getRepos(String accessToken) {

        return webClient.get()
                .uri("/user/repos")
                .header("Authorization","Bearer "+accessToken)
                .retrieve()
                .bodyToFlux(GithubRepoResopnse.class)
                .map(GithubRepoResopnse::getName)
                .collectList();


        }
}
