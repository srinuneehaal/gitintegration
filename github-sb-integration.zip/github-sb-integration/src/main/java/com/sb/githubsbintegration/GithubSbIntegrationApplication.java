package com.sb.githubsbintegration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GithubSbIntegrationApplication {

    public static void main(String[] args) {
        SpringApplication.run(GithubSbIntegrationApplication.class, args);
    }

}
